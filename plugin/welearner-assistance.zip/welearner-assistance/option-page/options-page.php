<?php
// create custom plugin settings menu
add_action('admin_menu', 'welearner_optons_page');

function welearner_optons_page() {

    //create new top-level menu
    add_menu_page('We Learner', 'We Lerner', 'administrator', 'welerneroptions', 'welerner_opton_page_fallback');

    //call register settings function
    add_action( 'admin_init', 'welearner_option_page_setting' );
}


function welearner_option_page_setting() {
    //register our settings
    register_setting( 'welerner-settings-group', 'footer_text' );
    register_setting( 'welerner-settings-group', 'facebook_link' );
    register_setting( 'welerner-settings-group', 'twitter_link' );
    register_setting( 'welerner-settings-group', 'linkdin_link' );
    register_setting( 'welerner-settings-group', 'footer_logo' );
}

function welerner_opton_page_fallback() {
?>
<div class="wrap">
<h1><?php echo esc_html__('We learner Setting', 'welerner-assistance'); ?> </h1>
<hr>
<form method="post" action="options.php">
<?php wp_nonce_field('update-options') ?>

    <?php settings_fields( 'welerner-settings-group' ); ?>
    <?php do_settings_sections( 'welerner-settings-group' ); ?>
    <table class="form-table">
        <tr>
                <td>
                    <label for="image_url" style="font-size: 20px; font-eight: bold"><?php echo esc_html__('Footer logo', 'welerner-assistance') ?> </label>
                    <?php if('' != get_option('footer_logo')): ?> 
                        <div class="preview-image">
                            <img src="<?php echo esc_attr( get_option('footer_logo') ); ?>" alt="footer logo">
                        </div>
                    <?php  endif; ?> 
                    <input type="text" name="footer_logo" id="image_url" class="regular-text" value="<?php echo esc_attr( get_option('footer_logo') ); ?>" style="display:none">
                    <input type="button" name="upload-btn" id="upload-btn" class="button-secondary" value="Upload Image">
                </td>
            </tr>
        <tr>
        <tr>
         <td><hr></td>
        </tr>
        <th><?php echo esc_html__('Footer Text', 'welerner-assistance'); ?></th>
            <td>
             <textarea name="footer_text" id="" cols="30" rows="10"><?php echo esc_attr( get_option('footer_text') ); ?></textarea>
            </td>
        </tr>
        <tr>
        <td><hr></td>
        </tr>
         <tr>
         <td>
            <h1><?php echo esc_html('Social options', 'welerner-assistance'); ?></h1>
         </td>
         </tr>
        <tr>
        <th scope="row">Facebook link</th>
        <td><input type="text" name="facebook_link" value="<?php echo esc_attr( get_option('facebook_link') ); ?>" /></td>
        </tr>
        
        <tr valign="top">
        <th scope="row">Twitter link</th>
        <td><input type="text" name="twitter_link" value="<?php echo esc_attr( get_option('twitter_link') ); ?>" /></td>
        </tr>
        
        <tr valign="top">
        <th scope="row">Linkdin link</th>
        <td><input type="text" placeholder="Linkdin link" name="linkdin_link" value="<?php echo esc_attr( get_option('linkdin_link') ); ?>" /></td>
        </tr>
        
    </table>

    <?php submit_button(); ?>

</form>
</div>
<?php } 

// UPLOAD ENGINE
function load_wp_media_files() {
    wp_enqueue_media();
}
add_action( 'admin_enqueue_scripts', 'load_wp_media_files' );

   
