<?php

/**
 * Register a custom post type for courses .
 *
 */
function wpdocs_codex_course_init() {
    $labels = array(
        'name'                  => _x( 'Courses', 'Post type general name', 'welarner-assistance ' ),
        'singular_name'         => _x( 'Course', 'Post type singular name', 'welarner-assistance ' ),
        'menu_name'             => _x( 'Courses', 'Admin Menu text', 'welarner-assistance ' ),
        'name_admin_bar'        => _x( 'Course', 'Add New on Toolbar', 'welarner-assistance ' ),
        'add_new_item'          => __( 'Add New Course', 'welarner-assistance ' ),
        'new_item'              => __( 'New Course', 'welarner-assistance ' ),
        'edit_item'             => __( 'Edit Course', 'welarner-assistance ' ),
        'view_item'             => __( 'View Course', 'welarner-assistance ' ),
        'all_items'             => __( 'All Courses', 'welarner-assistance ' ),
        'search_items'          => __( 'Search Courses', 'welarner-assistance ' ),
        'parent_item_colon'     => __( 'Parent Courses:', 'welarner-assistance ' ),
        'not_found'             => __( 'No Courses found.', 'welarner-assistance ' ),
        'not_found_in_trash'    => __( 'No Courses found in Trash.', 'welarner-assistance ' ),
    );
 
    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'course' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array( 'title', 'editor', 'author', 'thumbnail' ),
    );
 
    register_post_type( 'courses', $args );

    unset( $args );
    unset( $labels );
    // register custom postype for testimonials 
    $labels = array(
        'name'                  => _x( 'Testimonials', 'Post type general name', 'welarner-assistance ' ),
        'singular_name'         => _x( 'Testimonial', 'Post type singular name', 'welarner-assistance ' ),
        'menu_name'             => _x( 'Testimonials', 'Admin Menu text', 'welarner-assistance ' ),
        'name_admin_bar'        => _x( 'Testimonial', 'Add New on Toolbar', 'welarner-assistance ' ),
        'view_item'             => __( 'View Testimonial', 'welarner-assistance ' ),
        'all_items'             => __( 'All Testimonial', 'welarner-assistance ' ),
    );
 
    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'testimonial' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array( 'title', 'editor', 'thumbnail' ),
    );
    register_post_type( 'testimonial', $args );

    unset( $args );
    unset( $labels );
    $labels = array(
        'name'                  => _x( 'Creators', 'Post type general name', 'welarner-assistance ' ),
        'singular_name'         => _x( 'Creator', 'Post type singular name', 'welarner-assistance ' ),
        'menu_name'             => _x( 'Creators', 'Admin Menu text', 'welarner-assistance ' ),
        'name_admin_bar'        => _x( 'Creator', 'Add New on Toolbar', 'welarner-assistance ' ),
        'add_new_item'          => __( 'Add New Creator', 'welarner-assistance ' ),
        'new_item'              => __( 'New Creator', 'welarner-assistance ' ),
        'edit_item'             => __( 'Edit Creator', 'welarner-assistance ' ),
        'view_item'             => __( 'View Creator', 'welarner-assistance ' ),
        'all_items'             => __( 'All Creators', 'welarner-assistance ' ),
        'search_items'          => __( 'Search Creators', 'welarner-assistance ' ),
        'parent_item_colon'     => __( 'Parent Creator:', 'welarner-assistance ' ),
        'not_found'             => __( 'No Creatorss found.', 'welarner-assistance ' ),
        'not_found_in_trash'    => __( 'No Creator found in Trash.', 'welarner-assistance ' ),
    );
 
    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'creator' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array( 'title', 'thumbnail'),
    );

    register_post_type( 'creator', $args );

}
 
add_action( 'init', 'wpdocs_codex_course_init' );

//  register taxonomy for course 

/**
 * @see register_post_type() for registering custom post types.
 */
function wpdocs_create_topic_taxonomies() {
    $labels = array(
        'name'              => _x( 'Topics', 'taxonomy general name', 'welearner-assistance' ),
        'singular_name'     => _x( 'Topic', 'taxonomy singular name', 'welearner-assistance' ),
        'search_items'      => __( 'Search Topics', 'welearner-assistance' ),
        'all_items'         => __( 'All Topics', 'welearner-assistance' ),
        'parent_item'       => __( 'Parent Topic', 'welearner-assistance' ),
        'parent_item_colon' => __( 'Parent Topic:', 'welearner-assistance' ),
        'edit_item'         => __( 'Edit Topic', 'welearner-assistance' ),
        'update_item'       => __( 'Update Topic', 'welearner-assistance' ),
        'add_new_item'      => __( 'Add New Topic', 'welearner-assistance' ),
        'new_item_name'     => __( 'New Topic Name', 'welearner-assistance' ),
        'menu_name'         => __( 'Topic', 'welearner-assistance' ),
    );
 
    $args = array(
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array( 'slug' => 'topic' ),
    );
 
    register_taxonomy( 'topic', array( 'courses' ), $args );

 
}
// hook into the init action and call create_book_taxonomies when it fires
add_action( 'init', 'wpdocs_create_topic_taxonomies', 0 );