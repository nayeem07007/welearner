<?php 
/*
 * Register theme footer widgets 
*/

if ( function_exists('register_sidebar') ) {
    $sidebar1 = array(
        'id' => 'footer-1',
        'before_widget' => '<div class="col-sm-3 %2$s"><div class="footer-widget-wrapper">',
        'after_widget' => '</div></div>',
        'before_title' => '<h3 class="footer-widgets-title">',
        'after_title' => '</h3>',        
        'name'=>__( 'Footer 1', 'welerner-assistance' ),  
    );  
    $sidebar2 = array(
        'id' => 'footer-2',
        'before_widget' => '<div class="col-sm-3 %2$s"><div class="footer-widget-wrapper">',
        'after_widget' => '</div></div>',
        'before_title' => '<h3 class="footer-widgets-title">',
        'after_title' => '</h3>',        
        'name'=>__( 'Footer 2', 'welerner-assistance' ),  
    );
    $sidebar3 = array(
        'id' => 'footer-3',
        'before_widget' => '<div class="col-sm-3 %2$s"><div class="footer-widget-wrapper">',
        'after_widget' => '</div></div>',
        'before_title' => '<h3 class="footer-widgets-title">',
        'after_title' => '</h3>',        
        'name'=>__( 'Footer 3', 'welerner-assistance' ),  
    );
    $sidebar4 = array(
        'id' => 'footer-4',
        'before_widget' => '<div class="col-sm-3 %2$s"><div class="footer-widget-wrapper">',
        'after_widget' => '</div></div>',
        'before_title' => '<h3 class="footer-widgets-title">',
        'after_title' => '</h3>',        
        'name'=>__( 'Footer 4', 'welerner-assistance' ),  
    );
     
    register_sidebar($sidebar1);
    register_sidebar($sidebar2);
    register_sidebar($sidebar3);
    register_sidebar($sidebar4);
}
