<?php 
/*
Plugin Name: Welearner Assistacne 
Plugin URI: http://wordpress.org/
Description: Assistance plugin for Welearner theme 
Author: Md Nayeem Farid
Version: 1.0
Author URI: http://wordpress.org/mdnayeem
text-domain: welarner-assistance 
*/

// input custom postype 

require_once(__DIR__.'/init.php');


// Load required script and css 

// admin script 

add_action('admin_enqueue_scripts', 'welearner_assistance_admin_script');

function welearner_assistance_admin_script($hook) {

    $option_page = explode("/",$hook);
    $option_page_current = end($option_page);
   
    if($option_page_current != 'toplevel_page_welerneroptions') return;

    wp_enqueue_script( 'welernar-upload-script', plugin_dir_url( __FILE__ ) . 'assets/js/welernar-upload-script.js', [ 'jquery' ] );
    wp_enqueue_media();
    
}