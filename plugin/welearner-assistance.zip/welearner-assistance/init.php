<?php 

// install custom postype

require_once(__DIR__.'/custom-postype/custom-postype.php');

// register Sidebar 

require_once(__DIR__.'/widgets/widgets.php');


//  add option page 

require_once(__DIR__.'/option-page/options-page.php');